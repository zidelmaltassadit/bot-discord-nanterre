import discord
from discord.ext import commands

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}')

@bot.command()
async def info(ctx):
    await ctx.send("Pour vous inscrire à SEGMI, veuillez visiter notre site et suivre les instructions sur la page des inscriptions.")

@bot.command()
async def program(ctx):
    await ctx.send("Voici le programme des examens : ...")

@bot.command()
async def events(ctx):
    await ctx.send("Les événements à venir sont : ...")

@bot.command()
async def contact(ctx):
    await ctx.send("Pour contacter les responsables de SEGMI, envoyez un message à contact@segmi.com")

# Remplace 'your_token' par le token réel de ton bot
bot.run('your_token')
