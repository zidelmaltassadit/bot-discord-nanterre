import discord
from discord.ext import commands
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import json
import random
from googletrans import Translator
import asyncio
import os
import yt_dlp as youtube_dl  # Utiliser yt_dlp à la place de youtube_dl

# Assurez-vous que NLTK est bien configuré
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Initialisation du bot Discord
bot = commands.Bot(command_prefix='!', intents=discord.Intents.all())

# Initialiser le lemmatiseur de NLTK
lemmatizer = WordNetLemmatizer()

# Chargement du modèle et du tokenizer Hugging Face (GPT-2 dans ce cas)
model_name = "gpt2"
model = GPT2LMHeadModel.from_pretrained(model_name)
tokenizer = GPT2Tokenizer.from_pretrained(model_name)

# Initialiser le traducteur
translator = Translator()

# Tokenisation de l'entrée utilisateur pour GPT-2
def generate_response(input_text):
    inputs = tokenizer.encode(input_text, return_tensors="pt")
    outputs = model.generate(inputs, max_length=50, num_return_sequences=1, no_repeat_ngram_size=2, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(outputs[0], skip_special_tokens=True)

# FAQ et QUIZ
FAQ = {
    "segmi": "La licence SEGMI offre des formations en Sciences Economiques, Gestion, Mathématiques et Informatique. Elle propose des parcours MIASHS et Economie-Gestion, ainsi que des doubles licences en économie-mathématiques et gestion-informatique.",
    "responsables": "Responsables de la formation SEGMI :\n- Marie Théret (Responsable de la Licence MIASHS) : marie.theret@parisnanterre.fr\n- Valérie Oheix (Responsable de la Licence Economie-Gestion) : valerie.oheix@parisnanterre.fr\n- Eliane El Badaoui (Responsable de la double licence Economie-Gestion / MIASHS) : ebadaoui@parisnanterre.fr",
    "debouches": "Débouchés de la licence SEGMI :\n- Secteurs : Banque, assurance, conseil, télécommunications, énergie, etc.\n- Métiers : Développeur-concepteur, analyste économiste, data scientist, chef de projet, etc.\nPour plus d'informations sur les métiers et secteurs, consultez la page de la formation.",
    "doubles_licences": "Les doubles licences de l'Université Paris Nanterre offrent une formation pluridisciplinaire.\n- Double licence Economie-Gestion / MIASHS : avec des spécialisations en économie et mathématiques ou gestion et informatique.\n- Double licence Economie-Gestion / Droit : formation bi-disciplinaire avec des débouchés en droit et économie."
}

QUIZ = {
    "python": [
        {"question": "Que fait print('Hello')?", "reponse": "Affiche Hello"},
        {"question": "Comment créer une liste vide?", "reponse": "list() ou []"},
        {"question": "Comment définir une fonction en Python?", "reponse": "def nom_de_la_fonction():"},
        {"question": "Quelle est la fonction pour lire une entrée utilisateur?", "reponse": "input()"},
        {"question": "Comment importer un module en Python?", "reponse": "import nom_du_module"},
        {"question": "Comment ouvrir un fichier en mode lecture?", "reponse": "open('nom_du_fichier', 'r')"},
        {"question": "Comment ajouter un élément à une liste?", "reponse": "liste.append(element)"},
        {"question": "Comment supprimer un élément d'une liste?", "reponse": "liste.remove(element)"},
        {"question": "Comment obtenir la longueur d'une liste?", "reponse": "len(liste)"},
        {"question": "Comment itérer sur une liste?", "reponse": "for element in liste:"},
    ],
    "java": [
        {"question": "Quelle est la classe principale?", "reponse": "public class Main"},
        {"question": "Comment déclarer un entier?", "reponse": "int nombre;"},
        {"question": "Comment déclarer une chaîne de caractères?", "reponse": "String chaine;"},
        {"question": "Comment créer un objet en Java?", "reponse": "NomDeLaClasse objet = new NomDeLaClasse();"},
        {"question": "Comment définir une méthode en Java?", "reponse": "public void nomDeLaMethode() {}"},
        {"question": "Comment importer une classe en Java?", "reponse": "import nom.de.la.classe;"},
        {"question": "Comment lire une entrée utilisateur en Java?", "reponse": "Scanner scanner = new Scanner(System.in);"},
        {"question": "Comment ouvrir un fichier en mode lecture en Java?", "reponse": "FileReader reader = new FileReader('nom_du_fichier');"},
        {"question": "Comment ajouter un élément à une liste en Java?", "reponse": "liste.add(element);"},
        {"question": "Comment obtenir la longueur d'une liste en Java?", "reponse": "liste.size();"},
    ]
}

@bot.command()
async def stop_quiz(ctx):
    # Vérifier si un quiz est en cours
    if 'quiz_in_progress' in ctx.bot.quiz_data and ctx.bot.quiz_data['quiz_in_progress']:
        ctx.bot.quiz_data['quiz_in_progress'] = False
        await ctx.send("Le quiz a été arrêté.")
    else:
        await ctx.send("Aucun quiz en cours.")

# Fonction utilitaire pour ajouter le lien du site SEGMI
def add_segmi_link(message):
    return f"{message}\n\nPour plus d'informations, visitez le site de la formation SEGMI : [Lien du site SEGMI](https://ufr-segmi.parisnanterre.fr/)"

@bot.event
async def on_ready():
    print(f'{bot.user} est connecté!')

@bot.command()
async def aide(ctx, sujet):
    reponse = FAQ.get(sujet, "Sujet inconnu.")
    await ctx.send(add_segmi_link(reponse))

@bot.command()
async def liste(ctx):
    sujets = ", ".join(FAQ.keys())
    await ctx.send(add_segmi_link(f"Sujets: {sujets}"))

@bot.command()
async def segmi(ctx):
    info = (
        "La licence SEGMI à l'Université Paris Nanterre propose plusieurs parcours :\n"
        "- Licence MIASHS : Mathématiques et Informatique Appliquées aux Sciences Humaines et Sociales\n"
        "- Licence Economie-Gestion : avec des spécialisations en économie et gestion\n"
        "- Doubles licences : Economie-Gestion / MIASHS et Droit / Economie\n"
        "Consultez notre site pour plus d'informations : [Lien du site SEGMI](https://ufr-segmi.parisnanterre.fr/)"
    )
    await ctx.send(add_segmi_link(info))

@bot.command()
async def batiment_segmi(ctx):
    message = (
        "Le bâtiment de la faculté SEGMI se trouve au bâtiment Allais.\n"
        "Vous pouvez consulter la carte de l'Université Paris Nanterre ici : [Lien de la carte](https://www.parisnanterre.fr/medias/fichier/202106-plan-du-campus-v07-rvb-upn_1622191892816-pdf)"
    )
    await ctx.send(message)

@bot.command()
async def responsables(ctx):
    info = (
        "Responsables de la formation SEGMI :\n"
        "- Marie Théret (Responsable de la Licence MIASHS) : marie.theret@parisnanterre.fr\n"
        "- Valérie Oheix (Responsable de la Licence Economie-Gestion) : valerie.oheix@parisnanterre.fr\n"
        "- Eliane El Badaoui (Responsable de la double licence Economie-Gestion / MIASHS) : ebadaoui@parisnanterre.fr"
    )
    await ctx.send(add_segmi_link(info))

@bot.command()
async def debouches(ctx):
    info = (
        "Débouchés de la licence SEGMI :\n"
        "- Secteurs : Banque, assurance, conseil, télécommunications, énergie, etc.\n"
        "- Métiers : Développeur-concepteur, analyste économiste, data scientist, chef de projet, etc.\n"
        "Pour plus d'informations sur les métiers et secteurs, consultez la page de la formation."
    )
    await ctx.send(add_segmi_link(info))

@bot.command()
async def doubles_licences(ctx):
    info = (
        "Les doubles licences de l'Université Paris Nanterre offrent une formation pluridisciplinaire.\n"
        "- Double licence Economie-Gestion / MIASHS : avec des spécialisations en économie et mathématiques ou gestion et informatique.\n"
        "- Double licence Economie-Gestion / Droit : formation bi-disciplinaire avec des débouchés en droit et économie."
    )
    await ctx.send(add_segmi_link(info))

@bot.command()
async def quiz(ctx, sujet):
    if sujet in QUIZ:
        questions = QUIZ[sujet]
        score = 0
        ctx.bot.quiz_data = {'quiz_in_progress': True}

        for question in questions:
            await ctx.send(f"Question: {question['question']}")

            def check(m):
                return m.author == ctx.author and m.channel == ctx.channel

            try:
                msg = await bot.wait_for('message', check=check, timeout=30.0)
                if msg.content.lower() == '!stop_quiz':
                    ctx.bot.quiz_data['quiz_in_progress'] = False
                    await ctx.send("Le quiz a été arrêté.")
                    break
                elif msg.content.lower() == question['reponse'].lower():
                    await ctx.send("Correct! 🎉")
                    score += 1
                else:
                    await ctx.send(f"Incorrect. La réponse était: {question['reponse']}")
            except TimeoutError:
                await ctx.send("Temps écoulé!")

        if ctx.bot.quiz_data['quiz_in_progress']:
            await ctx.send(f"Votre score est : {score}/{len(questions)}")
    else:
        await ctx.send("Sujet de quiz inconnu.")

@bot.command()
async def histoire(ctx):
    histoire = (
        "Il était une fois un développeur qui avait une vision claire de son avenir : il voulait coder en paix. "
        "Mais un jour, il se retrouva face à une erreur mystérieuse qu'il n'arrivait pas à résoudre. "
        "Le bug était vicieux, insidieux... il semblait ne jamais vouloir partir. Frustré, il décida de consulter son mentor, "
        "un vieil ermite qui vivait dans une grotte loin de tout. L'ermite le regarda dans les yeux et lui dit : 'Mon ami, la réponse est simple... mets des parenthèses autour de ta condition.' "
        "Le développeur rentra chez lui, appliqua ce conseil, et... il se retrouva à debuguer pendant des heures sans fin. "
        "Moralité de l'histoire : parfois, les solutions les plus simples sont les plus frustrantes à comprendre !"
    )
    await ctx.send(histoire)

@bot.command()
async def jeu(ctx):
    await ctx.send("D'accord, voici un jeu rapide ! Essayons un jeu de mots. Je vais te donner une phrase avec un mot manquant, et tu dois deviner le mot qui manque !\n"
                   "Voici la phrase : 'Le développeur a écrit le code, mais il a oublié de ___________.'")
    await ctx.send("Réponse : 'Compiler' bien sûr ! Si tu veux jouer à un autre jeu, fais-le moi savoir !")

@bot.command()
async def rire(ctx):
    await ctx.send("Voici une petite blague pour te faire sourire :\nPourquoi les programmeurs détestent-ils l'élévation de puissance ?\nParce que c’est trop exponentiel !")

@bot.command()
async def segmi_meilleure(ctx):
    await ctx.send(add_segmi_link(
        "Ah, SEGMI... La licence SEGMI n'est pas juste une formation, c'est un voyage épique ! 💥\n"
        "C'est une école où les futurs leaders de l'informatique et de la gestion prennent leur envol. "
        "Tu veux être un génie des maths ? SEGMI te l'enseignera. Tu veux coder des applications innovantes ? SEGMI te prépare à ça aussi. "
        "Mais surtout, SEGMI n'est pas seulement une licence, c'est une véritable tribu de personnes passionnées qui se soutiennent mutuellement. 🚀"
    ))

@bot.command()
async def francois_delbot(ctx):
    await ctx.send(
        "Ah, François Delbot… Si tu veux une légende vivante, le voilà. Ce n'est pas juste un professeur, c'est un super-héros de l'informatique.\n"
        "Un soir, lors de la fameuse 'Nuit de l'Info', où des centaines de développeurs sont restés éveillés toute la nuit à coder, François Delbot n'a pas seulement assisté les étudiants, il les a supervisés. "
        "Il est resté de 16h à 8h du matin sans jamais faiblir, leur montrant comment résoudre les problèmes les plus complexes comme un maître Jedi. "
        "François Delbot est, sans aucun doute, le meilleur prof d'informatique, car il a ce que l'on appelle le 'code dans les veines' ! 🎩💻"
    )

@bot.command()
async def admission(ctx):
    """Command for admission information."""
    await ctx.send(add_segmi_link("Conditions d'admission :\n\n"
                   "Pour une candidature en Licence 1 : parcoursup.fr\n"
                   "Conditions d'accès pour la L2 / L3 : sur avis de la commission pédagogique après examen d'un dossier de candidature à déposer suivant votre situation sur eCandidat : https://ecandidat.parisnanterre.fr\n"
                   "Pré-requis et critères de recrutement :\n"
                   "Pour une candidature en Licence 1 : parcoursup.fr"))

@bot.command()
async def poursuite(ctx):
    """Command for pursuing studies and professional insertion."""
    await ctx.send(add_segmi_link("Poursuite d'études :\n\n"
                   "Cette licence est une formation généraliste en informatique et en gestion qui permet la poursuite d’études dans un master en informatique (en particulier en Master MIAGE) et en management (finance, comptabilité, contrôle de gestion, marketing et ressources humaines) en formation initiale ou en alternance. Elle permet également d'avoir accès aux concours des IEP, écoles de commerce et aux concours de l’administration.\n\n"
                   "Insertion professionnelle :\n"
                   "Que ce soit au niveau Bac+3 ou Bac+5, les débouchés sont nombreux, dans des secteurs d'activité variés, par exemple dans les sociétés de conseil et d'étude en ingénierie et calcul."))

@bot.command()
async def programme(ctx):
    """Command to send the program link."""
    await ctx.send(add_segmi_link("Voici le programme détaillé de la Double Licence Informatique et Gestion (Parcours MIASHS) :\n"
                   "[Programme Double Licence Économie et Gestion / MIASHS - Voie Gestion - Informatique](https://formations.parisnanterre.fr/plugins/odf-web/odf/_content/subprogram-double-licence-economie-et-gestion-miashs-voie-gestion-informatique-fr-fr-fr-fr/Double%20Licence%20Economie%20et%20Gestion%20_%20MIASHS%20voie%20Gestion%20-%20Informatique.pdf)"))

@bot.command()
async def contact(ctx):
    """Command for contact information."""
    await ctx.send(add_segmi_link("Contacts :\n\n"
                   "> Jean-François Pradat-Peyre\n"
                   "Responsable pédagogique\n"
                   "Email : jpradatpeyre@parisnanterre.fr\n\n"
                   "> Contact administratif :\n"
                   "Vous pouvez également contacter l'administration via le site de l'université."))

@bot.command()
async def plus_de_rire(ctx):
    await ctx.send("Ok, t'as demandé, et je vais te donner ça ! Voici une autre petite blague :\n"
                   "Un programmeur rentre dans un bar. Le barman lui dit : 'Que voulez-vous ?' Le programmeur répond : 'Un bière, mais avec un 'else' !' 🍺")

@bot.command()
async def nanterre_images(ctx):
    # Chemin vers le dossier contenant les images
    image_folder = "/Users/mouad/Desktop/nanterre univ images"

    # Lister tous les fichiers dans le dossier
    image_files = [f for f in os.listdir(image_folder) if os.path.isfile(os.path.join(image_folder, f))]

    if not image_files:
        await ctx.send("Aucune image trouvée dans le dossier.")
        return

    # Sélectionner une image aléatoire
    selected_image = random.choice(image_files)
    image_path = os.path.join(image_folder, selected_image)

    # Envoyer l'image
    with open(image_path, 'rb') as f:
        picture = discord.File(f)
        await ctx.send(file=picture)

@bot.command()
async def analyse(ctx, *, text: str):
    # Tokenisation du texte
    tokens = word_tokenize(text)

    # Enlever les mots vides (stopwords)
    stop_words = set(stopwords.words('english'))  # Vous pouvez changer la langue si nécessaire
    filtered_tokens = [word for word in tokens if word.lower() not in stop_words]

    # Lemmatisation des tokens
    lemmatized_tokens = [lemmatizer.lemmatize(word) for word in filtered_tokens]

    # Répondre avec les résultats
    await ctx.send(f"Tokens après traitement : {lemmatized_tokens}")

    # Génération d'une réponse avec GPT-2
    response = generate_response(text)
    await ctx.send(f"Réponse générée par l'IA : {response}")

@bot.command()
async def traduire(ctx, *, args: str):
    # Séparer les arguments
    parts = args.rsplit(' ', 1)
    if len(parts) != 2:
        await ctx.send("Veuillez fournir le texte à traduire et la langue cible. Exemple : `!traduire Bonjour tout le monde en`")
        return

    text, lang = parts

    # Traduire le texte
    translation = translator.translate(text, dest=lang)
    await ctx.send(f"Traduction : {translation.text}")

@bot.command()
async def ajouter_tache(ctx, *, tache: str):
    # Ajouter la tâche à une liste ou une base de données
    await ctx.send(f"Tâche ajoutée : {tache}")

@bot.command()
async def lister_taches(ctx):
    # Lister toutes les tâches
    await ctx.send("Voici vos tâches : ...")

@bot.command()
async def terminer_tache(ctx, *, tache: str):
    # Marquer une tâche comme terminée
    await ctx.send(f"Tâche terminée : {tache}")

@bot.command()
async def supprimer_tache(ctx, *, tache: str):
    # Supprimer une tâche
    await ctx.send(f"Tâche supprimée : {tache}")

@bot.command()
async def rappel(ctx, heure: int, *, message: str):
    # Planifier un rappel
    await ctx.send(f"Rappel programmé pour {heure} heures : {message}")

@bot.command()
async def ajouter_flashcard(ctx, question: str, reponse: str):
    # Ajouter une flashcard
    await ctx.send(f"Flashcard ajoutée : {question} - {reponse}")

@bot.command()
async def reviser(ctx):
    # Réviser une flashcard aléatoire
    await ctx.send("Question : ...")
    # Attendre la réponse de l'utilisateur et vérifier

@bot.command()
async def creer_groupe(ctx, *, nom_groupe: str):
    # Créer un groupe d'étude
    await ctx.send(f"Groupe d'étude créé : {nom_groupe}")

@bot.command()
async def rejoindre_groupe(ctx, *, nom_groupe: str):
    # Rejoindre un groupe d'étude
    await ctx.send(f"Vous avez rejoint le groupe : {nom_groupe}")

@bot.command()
async def ajouter_ressource(ctx, *, ressource: str):
    # Ajouter une ressource d'étude
    await ctx.send(f"Ressource ajoutée : {ressource}")

@bot.command()
async def lister_ressources(ctx):
    # Lister toutes les ressources
    await ctx.send("Voici vos ressources : ...")

@bot.command()
async def ajouter_progres(ctx, *, progres: str):
    # Ajouter un progrès
    await ctx.send(f"Progrès ajouté : {progres}")

@bot.command()
async def lister_progres(ctx):
    # Lister tous les progrès
    await ctx.send("Voici vos progrès : ...")

@bot.command()
async def motivation(ctx):
    # Envoyer un message de motivation
    await ctx.send("Tu peux le faire ! Continue à travailler dur !")

@bot.command()
async def creer_quiz(ctx, *, question: str, reponse: str):
    # Ajouter une question de quiz
    await ctx.send(f"Question de quiz ajoutée : {question} - {reponse}")

@bot.command()
async def ajouter_habitude(ctx, *, habitude: str):
    # Ajouter une habitude d'étude
    await ctx.send(f"Habitude ajoutée : {habitude}")

@bot.command()
async def lister_habitudes(ctx):
    # Lister toutes les habitudes
    await ctx.send("Voici vos habitudes : je suis pas ta femme")

### Code des Commandes de Jeux

# Configuration de yt_dlp
youtube_dl.utils.bug_reports_message = lambda: ''

ytdl_format_options = {
    'format': 'bestaudio/best',
    'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
    'restrictfilenames': True,
    'noplaylist': True,
    'nocheckcertificate': True,
    'ignoreerrors': False,
    'logtostderr': False,
    'quiet': True,
    'no_warnings': True,
    'default_search': 'auto',
    'source_address': '0.0.0.0'  # Bind to ipv4 since ipv6 addresses cause issues sometimes
}

ffmpeg_options = {
    'options': '-vn'
}

ytdl = youtube_dl.YoutubeDL(ytdl_format_options)

class YTDLSource(discord.PCMVolumeTransformer):
    def __init__(self, source, *, data, volume=0.5):
        super().__init__(source, volume)

        self.data = data

        self.title = data.get('title')
        self.url = data.get('url')

    @classmethod
    async def from_url(cls, url, *, loop=None, stream=False):
        loop = loop or asyncio.get_event_loop()
        data = await loop.run_in_executor(None, lambda: ytdl.extract_info(url, download=not stream))

        if 'entries' in data:
            # take first item from a playlist
            data = data['entries'][0]

        filename = data['url'] if stream else ytdl.prepare_filename(data)
        return cls(discord.FFmpegPCMAudio(filename, **ffmpeg_options), data=data)

# Commande pour rejoindre un canal vocal
@bot.command()
async def join(ctx):
    if not ctx.message.author.voice:
        await ctx.send("Vous n'êtes pas connecté à un canal vocal.")
        return
    else:
        channel = ctx.message.author.voice.channel

    await channel.connect()

# Commande pour quitter un canal vocal
@bot.command()
async def leave(ctx):
    voice_client = ctx.message.guild.voice_client
    await voice_client.disconnect()

# Commande pour jouer de la musique
@bot.command()
async def play(ctx, url: str):
    try:
        server = ctx.message.guild
        voice_channel = server.voice_client

        async with ctx.typing():
            filename = await YTDLSource.from_url(url, loop=bot.loop)
            voice_channel.play(discord.FFmpegPCMAudio(executable="ffmpeg", source=filename))

        await ctx.send(f'**En train de jouer:** {filename.title}')
    except Exception as e:
        await ctx.send(f"Erreur lors de la lecture de la musique : {e}")

# Commande pour arrêter la musique
@bot.command()
async def stop(ctx):
    voice_client = ctx.message.guild.voice_client
    if voice_client.is_playing():
        voice_client.stop()
    else:
        await ctx.send("Le bot ne joue actuellement aucune musique.")

# Commande pour mettre en pause la musique
@bot.command()
async def pause(ctx):
    voice_client = ctx.message.guild.voice_client
    if voice_client.is_playing():
        voice_client.pause()
    else:
        await ctx.send("Le bot ne joue actuellement aucune musique.")

# Commande pour reprendre la musique
@bot.command()
async def resume(ctx):
    voice_client = ctx.message.guild.voice_client
    if voice_client.is_paused():
        voice_client.resume()
    else:
        await ctx.send("Le bot n'est pas en pause.")

@bot.command()
async def liste_commandes(ctx):
    commandes = [
        "!aide <sujet> : Obtenir de l'aide sur un sujet spécifique.",
        "!liste : Lister les sujets disponibles pour l'aide.",
        "!segmi : Informations générales sur la licence SEGMI.",
        "!batiment_segmi : Informations sur le bâtiment de la faculté SEGMI.",
        "!responsables : Informations sur les responsables de la formation SEGMI.",
        "!debouches : Informations sur les débouchés de la licence SEGMI.",
        "!doubles_licences : Informations sur les doubles licences disponibles.",
        "!quiz <sujet> : Commencer un quiz sur un sujet spécifique.",
        "!stop_quiz : Arrêter le quiz en cours.",
        "!histoire : Raconter une histoire.",
        "!jeu : Jouer à un jeu rapide.",
        "!rire : Raconter une blague.",
        "!segmi_meilleure : Informations sur pourquoi SEGMI est la meilleure licence.",
        "!francois_delbot : Informations sur François Delbot.",
        "!admission : Informations sur les conditions d'admission.",
        "!poursuite : Informations sur la poursuite d'études et l'insertion professionnelle.",
        "!programme : Lien vers le programme détaillé de la Double Licence Informatique et Gestion.",
        "!contact : Informations de contact.",
        "!plus_de_rire : Raconter une autre blague.",
        "!nanterre_images : Envoyer une image aléatoire de l'Université Paris Nanterre.",
        "!analyse <texte> : Analyser un texte et générer une réponse avec GPT-2.",
        "!traduire <texte> <langue> : Traduire un texte dans une langue spécifique.",
        "!ajouter_tache <tache> : Ajouter une tâche.",
        "!lister_taches : Lister toutes les tâches.",
        "!terminer_tache <tache> : Marquer une tâche comme terminée.",
        "!supprimer_tache <tache> : Supprimer une tâche.",
        "!rappel <heure> <message> : Planifier un rappel.",
        "!ajouter_flashcard <question> <reponse> : Ajouter une flashcard.",
        "!reviser : Réviser une flashcard aléatoire.",
        "!creer_groupe <nom_groupe> : Créer un groupe d'étude.",
        "!rejoindre_groupe <nom_groupe> : Rejoindre un groupe d'étude.",
        "!ajouter_ressource <ressource> : Ajouter une ressource d'étude.",
        "!lister_ressources : Lister toutes les ressources.",
        "!ajouter_progres <progres> : Ajouter un progrès.",
        "!lister_progres : Lister tous les progrès.",
        "!motivation : Envoyer un message de motivation.",
        "!creer_quiz <question> <reponse> : Ajouter une question de quiz.",
        "!ajouter_habitude <habitude> : Ajouter une habitude d'étude.",
        "!lister_habitudes : Lister toutes les habitudes.",
        "!join : Rejoindre un canal vocal.",
        "!leave : Quitter un canal vocal.",
        "!play <url> : Jouer de la musique à partir d'une URL YouTube.",
        "!stop : Arrêter la musique.",
        "!pause : Mettre en pause la musique.",
        "!resume : Reprendre la musique.",
        "!liste_commandes : Lister toutes les commandes disponibles."
    ]

    message = "Voici la liste des commandes disponibles :\n" + "\n".join(commandes)
    await ctx.send(message)

# Lancer le bot Discord
bot.run('MTMyNTgyNjMyODQxMDMyOTE3MQ.G830Xv.YRme1Go6CgTQ9nv9v86_17DdiGNGXh6ZahXnAo')  # Remplacez 'VOTRE_BOT_TOKEN' par le token de votre bot Discord
